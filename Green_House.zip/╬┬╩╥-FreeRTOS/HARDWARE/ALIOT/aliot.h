#ifndef _DEVICE_H_
#define _DEVICE_H_


#include "sys.h"
#include "stdio.h"
#include "string.h"

void aliot_co2_tx(void);
void aliot_ambient_temp_hum_tx(void);
void aliot_o2_tx(void);
void aliot_ota(void);
void aliot_soil_temp_hum_tx(void);

#endif
