#ifndef __AIR_H
#define __AIR_H
#include "sys.h"
#include "usart.h"

extern u8 data_buf[1000];
extern int began;
extern int end;
u8 air_send_cmd(char *cmd, char *ack, uint16_t waittime);
u8 air_send_data(char *cmd, char *ack, u16 waittime);
u8 air_connect_aliot(char *cmd, char *ack, u16 waittime);
char* air_check_cmd(char *str);
void air_aliot_init(void);
void air_poweron(void);
u8 air_send_net(char *cmd, char *ack, u16 waittime);
void airio_init(void);
void OTA_DATA_data_processing(void);
void uart_init(u32 pclk2,u32 bound);//1.���㲨����2.ʹ��ʱ�ӡ�IO�ڸ���3.ʹ���жϡ�����
void GPIO_AF_Set(GPIO_TypeDef* GPIOx,u8 BITx,u8 AFx);
void GPIO_Set(GPIO_TypeDef* GPIOx,u32 BITx,u32 MODE,u32 OTYPE,u32 OSPEED,u32 PUPD);
void MY_NVIC_Init(u8 NVIC_PreemptionPriority,u8 NVIC_SubPriority,u8 NVIC_Channel,u8 NVIC_Group);
void MY_NVIC_PriorityGroupConfig(u8 NVIC_Group);
#endif



