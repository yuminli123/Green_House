#ifndef __DHT11_H__
#define __DHT11_H__
#include "sys.h"
#include "delay.h"

void dht11_gpio_input(void);
void dht11_gpio_output(void);
u16 dht11_scan(void);
u16 dht11_read_bit(void);
u16 dht11_read_byte(void);
u16 dht11_read_data(u8 buffer[4]);

#endif


