#ifndef _LED_H
#define _LED_H
#include "sys.h"

#define LED0 PDout(12)   //LED0
#define LED1 PDout(13)   //LED1
#define LED2 PDout(14)   //LED2
#define LED3 PDout(11)   //LED2

void LED_Init(void);
void LED_ON(u8 led);
void LED_OFF(u8 led);
#endif
