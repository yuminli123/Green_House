#ifndef __DMA_H
#define __DMA_H
#include "sys.h"

extern DMA_HandleTypeDef  UART7RxDMA_Handler;      //DMA���
extern DMA_HandleTypeDef  UART4RxDMA_Handler;      //DMA���
extern DMA_HandleTypeDef  UART2RxDMA_Handler;      //DMA���

void MYDMA_Config(DMA_Stream_TypeDef *DMA_Streamx,u32 chx);
void DMA_UART4RX_Config(DMA_Stream_TypeDef *DMA_Streamx,u32 chx);
void DMA_UART2RX_Config(DMA_Stream_TypeDef *DMA_Streamx,u32 chx);
#endif
