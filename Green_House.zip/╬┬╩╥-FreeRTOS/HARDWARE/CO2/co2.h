#ifndef _CO2_H
#define _CO2_H
typedef unsigned short  int u16;
typedef unsigned        char u8;

extern u16 ppm_co2;
extern u8 SendBuff[50];
extern u8 change;
extern u8 pointBuff[50];
extern u8 begain_CO2[8];
extern u8 point_CO2[8];
extern const u16 u16CrcTalbeAbs[]; 

//CO2��������+С��������
void Quest_CO2(void);
void Quest_CO2_Point(void);
u16 Crc16(u8 * pchMsg, u8 wDataLen);

#endif




