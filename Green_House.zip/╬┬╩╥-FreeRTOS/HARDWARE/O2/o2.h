#ifndef _O2_H
#define _O2_H


void Send_bengain_O2(void);
void Receive_Data_O2(void);
int Get_O2_PPM(void);


#endif






